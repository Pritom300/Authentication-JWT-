﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Summeries.Data.Models;

namespace Summeries.Data.Services
{
    public class BookService : IBookService
    {

        private readonly ApplicationDbContext _db;


        public BookService(ApplicationDbContext db)
        {
            _db = db;
        }



        public void AddBook(Book newBook)
        {
            newBook.Id = 0;
            _db.Book.Add(newBook);
            _db.SaveChanges();
           
        }

        public void DeleteBook(int id)
        {
            var book = _db.Book.FirstOrDefault(n => n.Id == id);
            _db.Book.Remove(book);
            _db.SaveChanges();
        }

        public List<Book> GetAllBooks()
        {
            return _db.Book.ToList();
        }

        public Book GetBookById(int id)
        {
            return _db.Book.FirstOrDefault(n => n.Id == id);
        }

        public void UpdateBook(int id, Book newBook)
        {
            var oldBook = _db.Book.FirstOrDefault(n => n.Id == id);
            if (oldBook != null)
            {
                oldBook.Title = newBook.Title;
                oldBook.Author = newBook.Author;
                oldBook.Description = newBook.Description;
                oldBook.Rate = newBook.Rate;
                oldBook.DateStart = newBook.DateStart;
                oldBook.DateRead = newBook.DateRead;
            }
            _db.SaveChanges();
        }
    }
}
